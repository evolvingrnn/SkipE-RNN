clc
clear
close all

%% load data
data=load('\Datasets\UG_2C_5D-onehot.txt');  I = 5; name='UG_2C_5D';
%% run deep evolving RNN
[parameter,performance] = skipernn(data,I,name);
disp(performance)