clc
clear
close all
%The model executes considering the delay delta=1000
%% load data
load '\Datasets\datahyp'; I = 4; name='HypStack1000';
%% run deep evolving RNN

[parameter,performance] = skipernn(data,I,name);
disp(performance)